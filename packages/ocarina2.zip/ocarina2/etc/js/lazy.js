/**
	/etc/js/lazy.js
	(C) Giovanni Capuano 2011
*/

$("img").lazyload({      
	effect      : "fadeIn"
});
