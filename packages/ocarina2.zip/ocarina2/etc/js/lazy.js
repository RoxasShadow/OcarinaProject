/**
	/etc/js/lazy.js
	(C) Giovanni Capuano 2011
*/
$(document).ready(function(){$("img").lazyload({effect:"fadeIn"});});
