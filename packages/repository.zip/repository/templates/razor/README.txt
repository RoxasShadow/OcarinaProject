Scritta in HTML5 e CSS3 con il framework Blueprint, con i contenuti all'interno di un container e basato su colori scuri ed eleganti con il menù in cima.
(C) 2011 - Giovanni Capuano
