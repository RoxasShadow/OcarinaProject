<?php
class NoSpam extends Utilities implements FrameworkPlugin {
	public function main($templateVarList) {
		if(isset($_POST['comment']))
			$_POST['comment'] = parent::cleanTextFromURL($_POST['comment']);
	}
	
	public function install() {
		return true;
	}
	
	public function disinstall() {
		return true;
	}
}
