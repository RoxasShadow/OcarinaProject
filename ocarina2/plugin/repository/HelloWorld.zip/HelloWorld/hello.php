<?php
class Hello implements FrameworkPlugin {
	/* Ok, that's not an hello world, but is very cool, isn't it? :D */
	private $rendering = array();
	
	public function main($templateVarList) {
		$this->rendering['footer'] = '<p align="center">Proudly running on <a href="http://www.giovannicapuano.net">Ocarina2 CMS</a>.</p>';
		return $this->rendering;
	}
	
	public function install() {
		return true;
	}
	
	public function disinstall() {
		return true;
	}
}
