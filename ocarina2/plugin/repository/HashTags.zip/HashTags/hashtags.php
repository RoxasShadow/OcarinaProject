<?php
class HashTags extends Configuration implements FrameworkPlugin {
	/* $This is a hashtag~ */
	private $preHashTag = '$';
	private $afterHashTag = '~';
	private $preFinalHashTag = '#';
	private $afterFinalHashTag = '';
	
	public function main($templateVarList) {
		if(isset($templateVarList['commento'])) {
			for($i=0, $count=count($templateVarList['commento']); $i<$count; ++$i)
				$templateVarList['commento'][$i]->contenuto = $this->hashTagize($templateVarList['commento'][$i]->contenuto);
			$rendering['commento'] = $templateVarList['commento'];
		}
		elseif(isset($templateVarList['commenti'])) {
			for($i=0, $count=count($templateVarList['commenti']); $i<$count; ++$i)
				$templateVarList['commenti'][$i]->contenuto = $this->hashTagize($templateVarList['commenti'][$i]->contenuto);
			$rendering['commenti'] = $templateVarList['commenti'];
		}
	}
	
	private function hashTagize($comment) {
		if(isset($_GET['id']))
			return preg_replace('/\\'.$this->preHashTag.'(.*?)\\'.$this->afterHashTag.'/is', '<a href="'.$this->config[0]->url_index.'/ricerca.php?commenti=\\1">'.$this->preFinalHashTag.'\\1'.$this->afterFinalHashTag.'</a>', $comment);
		elseif(isset($_GET['titolo']))
			return preg_replace('/\\'.$this->preHashTag.'(.*?)\\'.$this->afterHashTag.'/is', '<a href="'.$this->config[0]->url_index.'/ricerca.php?commenti=\\1">'.$this->preFinalHashTag.'\\1'.$this->afterFinalHashTag.'</a>', $comment);
	}
	
	/*
	A simple snippet. You can use it how you want.
	private function highlightHashTags($comment) {
		for($i=0, $count=count($comment[0]); $i<$count; ++$i)
			$comment[$i]->contenuto = preg_replace('/\$(.*?)~/is', '<font color="red">#\\1</font>', $comment[$i]->contenuto);
		return $comment;
	}*/
	
	public function install() {
		return true;
	}
	
	public function disinstall() {
		return true;
	}
}
